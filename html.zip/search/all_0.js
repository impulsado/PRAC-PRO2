var searchData=
[
  ['_3cb_3e_20pràctica_20pro2_202023_2d2024_3a_20comerç_20fluvial_20_3c_2fb_3e_0',['&lt;b&gt; Pràctica PRO2 2023-2024: Comerç Fluvial &lt;/b&gt;',['../index.html',1,'']]]
];
