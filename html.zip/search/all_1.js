var searchData=
[
  ['actquant_1',['actQuant',['../classViatge.html#afa84ab6a9b842d058b6efe3902954b18',1,'Viatge']]],
  ['actviatge_2',['actViatge',['../classViatge.html#ab313588a14b32e853895d0345b32f251',1,'Viatge']]],
  ['afegirciutat_3',['afegirCiutat',['../classCjt__ciutats.html#a9de83b7c9fd99144589c2efa480fdbcd',1,'Cjt_ciutats::afegirCiutat()'],['../classVaixell.html#ae58cdeb92a9ab720544b7641d4043c7a',1,'Vaixell::afegirCiutat()'],['../classViatge.html#adfd63bc784d9dd3aba18290c5555441b',1,'Viatge::afegirCiutat()']]],
  ['afegirprodaciutat_4',['afegirProdACiutat',['../classCjt__ciutats.html#a8c3938d9ddaead4c915f068e120205df',1,'Cjt_ciutats']]],
  ['afegirprodalinventari_5',['afegirProdAlInventari',['../classCiutat.html#a3ec16c600fceb969a833006cea0e5041',1,'Ciutat']]],
  ['afegirproducte_6',['afegirProducte',['../classCjt__productes.html#a29110275aef3a6d9ec9c294bf5f56b04',1,'Cjt_productes']]],
  ['agregar_5fproductos_7',['agregar_productos',['../program_8cc.html#aee38d111d27fceb494822eab89815462',1,'program.cc']]]
];
