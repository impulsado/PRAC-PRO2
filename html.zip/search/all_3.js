var searchData=
[
  ['determinar_5fviatge_36',['determinar_viatge',['../classCjt__ciutats.html#a0cd4b523f4fbc979323eaf9471b1f7f0',1,'Cjt_ciutats']]],
  ['distancia_37',['distancia',['../classViatge.html#ab0befd4984e44af7df0e6c2ca7b36412',1,'Viatge']]]
];
