var searchData=
[
  ['pes_5ftotal_70',['pes_total',['../classCiutat.html#abd4885af9c76bf8edf1f213fdff5f4db',1,'Ciutat']]],
  ['poner_5fprod_71',['poner_prod',['../program_8cc.html#afe8b0fd4cf9875e371ce133268e84220',1,'program.cc']]],
  ['program_2ecc_72',['program.cc',['../program_8cc.html',1,'']]]
];
