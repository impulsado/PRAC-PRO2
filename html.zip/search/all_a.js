var searchData=
[
  ['quant_5fcomerciat_73',['quant_comerciat',['../classViatge.html#abb14c5265d87a108b644afc9d5204930',1,'Viatge']]],
  ['quant_5fprod_74',['quant_prod',['../classCjt__productes.html#a10227f9e0755a4c84e65353c9362c314',1,'Cjt_productes']]],
  ['quantitatpercomprar_75',['quantitatPerComprar',['../classLlanxa.html#ae991f3f460eb22338e63aded382140a4',1,'Llanxa::quantitatPerComprar()'],['../classVaixell.html#af611b40c85d678118661792832b34303',1,'Vaixell::quantitatPerComprar()']]],
  ['quantitatpervendre_76',['quantitatPerVendre',['../classLlanxa.html#af74289df0a10b94354da2dd203fb61b6',1,'Llanxa::quantitatPerVendre()'],['../classVaixell.html#aae3bd285c51ebbb32ead0703249a4415',1,'Vaixell::quantitatPerVendre()']]],
  ['quitar_5fprod_77',['quitar_prod',['../program_8cc.html#a4200cacc339f24b6a2f87a578da458a8',1,'program.cc']]]
];
