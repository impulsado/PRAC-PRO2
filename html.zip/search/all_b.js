var searchData=
[
  ['realitzar_5fviatge_78',['realitzar_viatge',['../classCjt__ciutats.html#afaf8508376f993cf560c5b3ac855aa65',1,'Cjt_ciutats']]],
  ['redistribuir_79',['redistribuir',['../classCjt__ciutats.html#a0ae1d9250ef610303944d9ee3cfcdb73',1,'Cjt_ciutats']]],
  ['registre_5fultimes_5fciutats_80',['registre_ultimes_ciutats',['../classVaixell.html#af7ffb7f846d25b72659e709d1107c013',1,'Vaixell']]],
  ['ruta_81',['ruta',['../classViatge.html#af511af2e6f2970e70ae63784fc2d8059',1,'Viatge']]]
];
