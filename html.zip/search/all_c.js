var searchData=
[
  ['teinventari_82',['teInventari',['../classCiutat.html#a10e784c413229cb9a2481320fa3be2e2',1,'Ciutat']]],
  ['teproducte_83',['teProducte',['../classCiutat.html#a21122021c79bcad356eee33dea257095',1,'Ciutat']]]
];
