var searchData=
[
  ['vaixell_84',['Vaixell',['../classVaixell.html',1,'Vaixell'],['../classVaixell.html#a87db4dc1f4f816d6b4277fab84bc6e2b',1,'Vaixell::Vaixell()']]],
  ['vaixell_2ecc_85',['Vaixell.cc',['../Vaixell_8cc.html',1,'']]],
  ['vaixell_2ehh_86',['Vaixell.hh',['../Vaixell_8hh.html',1,'']]],
  ['vendre_87',['vendre',['../classLlanxa.html#a679ee3b571d428997997593ae4ba7599',1,'Llanxa::vendre()'],['../classVaixell.html#a31307c2dc07a75ba770eaa773a1335b7',1,'Vaixell::vendre()']]],
  ['viatge_88',['Viatge',['../classViatge.html',1,'Viatge'],['../classViatge.html#ac35d9bc677d39a2706b89c3c5edfba7f',1,'Viatge::Viatge()']]],
  ['viatge_2ecc_89',['Viatge.cc',['../Viatge_8cc.html',1,'']]],
  ['viatge_2ehh_90',['Viatge.hh',['../Viatge_8hh.html',1,'']]],
  ['volum_5ftotal_91',['volum_total',['../classCiutat.html#aa3a49cb39f9a280cbc22c1b432fb320f',1,'Ciutat']]],
  ['vprod_92',['vprod',['../classCjt__productes.html#a165441f3f61ac181508b886513efaa3d',1,'Cjt_productes']]]
];
