var searchData=
[
  ['llanxa_96',['Llanxa',['../classLlanxa.html',1,'']]]
];
