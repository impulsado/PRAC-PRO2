var searchData=
[
  ['ciutat_119',['Ciutat',['../classCiutat.html#ac97a1f561bd09010ffce05552a477fc3',1,'Ciutat::Ciutat(string id_city)'],['../classCiutat.html#a0a02d9e0c5c53d1436364c7d6cf6ad8d',1,'Ciutat::Ciutat()']]],
  ['cjt_5fciutats_120',['Cjt_ciutats',['../classCjt__ciutats.html#a9b603b49a8196afaa02a6f5c2112588f',1,'Cjt_ciutats']]],
  ['cjt_5fproductes_121',['Cjt_productes',['../classCjt__productes.html#a31423e55514ad0805ba3806a5d5862b0',1,'Cjt_productes']]],
  ['comerciar_122',['comerciar',['../classCiutat.html#a4e5a93cfbd2bb365b6d28a2c79d81b76',1,'Ciutat::comerciar()'],['../classCjt__ciutats.html#a404c5324032b83e7a8c3f55544923fe7',1,'Cjt_ciutats::comerciar()'],['../classVaixell.html#ad83e1d2c19999a3dd41c848b7b608a9c',1,'Vaixell::comerciar()'],['../program_8cc.html#a11af517e7df5c149749f0b33f3708504',1,'comerciar():&#160;program.cc']]],
  ['comerciarsensemod_123',['comerciarSenseMod',['../classLlanxa.html#a7ce7a535909cc329172a205a419a6797',1,'Llanxa::comerciarSenseMod()'],['../classVaixell.html#a28022cdc527c782005c890f46193d6d2',1,'Vaixell::comerciarSenseMod()']]],
  ['consultar_5fprod_124',['consultar_prod',['../program_8cc.html#a770cd237ebed8979e3b4dc709d9e539f',1,'program.cc']]],
  ['consultarciutat_125',['consultarCiutat',['../classCjt__ciutats.html#a34a77a10e4fa9e9bbf9b6eb460b211eb',1,'Cjt_ciutats']]],
  ['consultarcompra_126',['consultarCompra',['../classVaixell.html#a52ddaaf70f593aa3a455f22d09705957',1,'Vaixell']]],
  ['consultardemanda_127',['consultarDemanda',['../classCiutat.html#a6667cb6dcd81adb2255aaf163b8bcb73',1,'Ciutat']]],
  ['consultardiferencia_128',['consultarDiferencia',['../classCiutat.html#a7b3231f2b0328919430991da4421e683',1,'Ciutat']]],
  ['consultardist_129',['consultarDist',['../classViatge.html#ad615727140707685e07093a605be2660',1,'Viatge']]],
  ['consultaroferta_130',['consultarOferta',['../classCiutat.html#aa09b8469ecf944323bbcf7a7b062f8b8',1,'Ciutat']]],
  ['consultarpestotal_131',['consultarPesTotal',['../classCiutat.html#a34007a186f3c19466cd2e64dcc3c38e0',1,'Ciutat']]],
  ['consultarproducte_132',['consultarProducte',['../classCjt__productes.html#a2a9703ef9f499a730bde6eb7a86df5ae',1,'Cjt_productes']]],
  ['consultarquant_133',['consultarQuant',['../classViatge.html#a9a91de1f64452016cda3190d45fdee47',1,'Viatge']]],
  ['consultarquantitatprod_134',['consultarQuantitatProd',['../classCjt__productes.html#aa15e98e1d3bdf1e22c50a07a93f5d6e3',1,'Cjt_productes']]],
  ['consultarruta_135',['consultarRuta',['../classViatge.html#a64e70653d734a187e23379e7744cef07',1,'Viatge']]],
  ['consultarultimaciutat_136',['consultarUltimaCiutat',['../classViatge.html#a2bdb9e677e4fc51136252fb1803945c0',1,'Viatge']]],
  ['consultarvenda_137',['consultarVenda',['../classVaixell.html#a16fc3c5406e00da469d3f60f7c2fbb8a',1,'Vaixell']]],
  ['consultarvolumtotal_138',['consultarVolumTotal',['../classCiutat.html#a99f5d70b8c1f95d5203b247d4ef69f14',1,'Ciutat']]]
];
