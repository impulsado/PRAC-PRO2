var searchData=
[
  ['determinar_5fviatge_139',['determinar_viatge',['../classCjt__ciutats.html#a0cd4b523f4fbc979323eaf9471b1f7f0',1,'Cjt_ciutats']]]
];
