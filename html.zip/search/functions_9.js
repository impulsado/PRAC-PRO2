var searchData=
[
  ['realitzar_5fviatge_172',['realitzar_viatge',['../classCjt__ciutats.html#afaf8508376f993cf560c5b3ac855aa65',1,'Cjt_ciutats']]],
  ['redistribuir_173',['redistribuir',['../classCjt__ciutats.html#a0ae1d9250ef610303944d9ee3cfcdb73',1,'Cjt_ciutats']]]
];
