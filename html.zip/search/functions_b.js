var searchData=
[
  ['vaixell_176',['Vaixell',['../classVaixell.html#a87db4dc1f4f816d6b4277fab84bc6e2b',1,'Vaixell']]],
  ['viatge_177',['Viatge',['../classViatge.html#ac35d9bc677d39a2706b89c3c5edfba7f',1,'Viatge']]]
];
