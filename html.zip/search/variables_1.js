var searchData=
[
  ['distancia_180',['distancia',['../classViatge.html#ab0befd4984e44af7df0e6c2ca7b36412',1,'Viatge']]]
];
