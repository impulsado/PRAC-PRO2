var searchData=
[
  ['id_181',['id',['../classCiutat.html#a974a782da1bfbb54bd180e8bfff69f29',1,'Ciutat']]],
  ['inventari_182',['inventari',['../classCiutat.html#a301fd5db0f0f8e42312fd9c28547a8cc',1,'Ciutat']]]
];
