var searchData=
[
  ['pes_5ftotal_183',['pes_total',['../classCiutat.html#abd4885af9c76bf8edf1f213fdff5f4db',1,'Ciutat']]]
];
