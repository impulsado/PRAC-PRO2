var searchData=
[
  ['quant_5fcomerciat_184',['quant_comerciat',['../classViatge.html#abb14c5265d87a108b644afc9d5204930',1,'Viatge']]],
  ['quant_5fprod_185',['quant_prod',['../classCjt__productes.html#a10227f9e0755a4c84e65353c9362c314',1,'Cjt_productes']]]
];
