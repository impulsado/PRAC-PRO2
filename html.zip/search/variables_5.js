var searchData=
[
  ['registre_5fultimes_5fciutats_186',['registre_ultimes_ciutats',['../classVaixell.html#af7ffb7f846d25b72659e709d1107c013',1,'Vaixell']]],
  ['ruta_187',['ruta',['../classViatge.html#af511af2e6f2970e70ae63784fc2d8059',1,'Viatge']]]
];
