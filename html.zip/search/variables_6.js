var searchData=
[
  ['vendre_188',['vendre',['../classLlanxa.html#a679ee3b571d428997997593ae4ba7599',1,'Llanxa::vendre()'],['../classVaixell.html#a31307c2dc07a75ba770eaa773a1335b7',1,'Vaixell::vendre()']]],
  ['volum_5ftotal_189',['volum_total',['../classCiutat.html#aa3a49cb39f9a280cbc22c1b432fb320f',1,'Ciutat']]],
  ['vprod_190',['vprod',['../classCjt__productes.html#a165441f3f61ac181508b886513efaa3d',1,'Cjt_productes']]]
];
